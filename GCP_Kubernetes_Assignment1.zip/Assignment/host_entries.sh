#! /bin/bash

kubernetes_master_ip=`gcloud compute instances describe kubernetes-master --zone us-central1-a --format='get(networkInterfaces[0].networkIP)'`
kubernetes_slave1_ip=`gcloud compute instances describe kubernetes-slave1 --zone us-central1-a --format='get(networkInterfaces[0].networkIP)'`
kubernetes_slave2_ip=`gcloud compute instances describe kubernetes-slave2 --zone us-central1-a --format='get(networkInterfaces[0].networkIP)'`

cat <<EOF > hosts.ini
[master]
$kubernetes_master_ip

[node]
$kubernetes_slave1_ip
$kubernetes_slave2_ip

[kube-cluster:children]
master
node
EOF
